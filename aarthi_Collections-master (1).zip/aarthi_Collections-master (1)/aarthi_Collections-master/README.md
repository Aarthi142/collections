# aarthi_Collections
EPAM home task on Collections
